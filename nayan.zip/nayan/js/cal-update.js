var calendario = {
    current: '3.2.0',
    previous: '3.1.0',
    download: 'https://raw.githubusercontent.com/codrops/Calendario/master/js/jquery.calendario.js',
    msg: 'CALENDARIO MSG' +
         '\n===============' +
         '\nNEW VERSION (3.2.0) AVAILABLE!' +
         '\nDOWNLOAD : https://raw.githubusercontent.com/codrops/Calendario/master/js/jquery.calendario.js' +
         '\nMINIFIED : https://raw.githubusercontent.com/codrops/Calendario/master/js/jquery.calendario.min.js' +
         '\n=================================================================================================='
};
